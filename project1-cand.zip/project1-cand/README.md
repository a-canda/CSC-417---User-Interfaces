### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.


In the terminal console, `npm start` will start running this program.
http://localhost:3000 will automatically open after running this command and will show the contents of this project.

This project is designed to use react and react components via react-bootstrap and react-bootstrap table. Two components are used. TableComponent and TableRow are the two component js files, where TableRow contains properties for each row defined in the TableComponent js file.